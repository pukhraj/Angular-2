﻿import { Component, OnInit } from '@angular/core';

import { User } from '../_models/index';
import { UserService } from '../_services/index';

@Component({
    moduleId: module.id.toString(),
    templateUrl: 'front.component.html'
})

export class FrontComponent implements OnInit {
    
    constructor(private userService: UserService) {
        
    }

    ngOnInit() {
    }

    

    
}